<?php

add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 200, 340 );

add_theme_support( 'custom-logo' );
add_theme_support( 'title-tag' );
add_theme_support( 'custom-header', [
    "uploads" => true
]); 

?>