<div style="height: 400px;">
    BIENVENIDA <?= strtoupper($user['first_name'].' '.$user['last_name']) ?>
</div>