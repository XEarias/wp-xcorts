<?php get_header(); ?>

<?php get_search_form(); ?>

<?php prepare_escorts_by_custom_search(); ?>

<?php get_template_part( 'template-parts/escort-list' ); ?>

<?php get_footer(); ?>
